package org.knipsX.utils.JAXB;

public class PictureHandler {

}

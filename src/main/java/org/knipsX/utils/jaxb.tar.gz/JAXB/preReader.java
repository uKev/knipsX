package org.knipsX.utils.JAXB;

import java.io.*;

import org.knipsX.utils.JAXB.parser.*;


public class preReader {
	
	 
//     Reader clyde = new Reader();
//     clyde.
     
     
     

}



